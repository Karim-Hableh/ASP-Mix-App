//////////////////////////////////////////////////////////////
//////////////////  YOUR FULL NAME - ID  /////////////////////

using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.EntityFrameworkCore;
using System;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddRazorPages();

//Data Base Registration
var conString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<AppDbContext>(
    options => options.UseSqlServer(conString));

builder.Services.AddScoped<ClientService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

//  --------- Minimal APIs - Endpoints  ----------- //
// Access Swagger at http://localhost:5050/swagger/index.html

app.MapGet("/SayHi", () => { return "HI"; });
app.MapPost("/AddCustomer",(ClientService service, ClientRequest request)=>service.AddCustomer(request));
app.MapPut("/CorrectBalance/{id}/{USD}/{LBP}",(ClientService service, int id,int USD,int LBP)=>service.CorrectBalance(id, USD, LBP));
app.MapGet("/GetCustomerInformation/{id}",(ClientService service,int id)=>service.GetCustomerById(id));



/////////////////////////////////////////////////////
app.MapRazorPages();
app.Run();
