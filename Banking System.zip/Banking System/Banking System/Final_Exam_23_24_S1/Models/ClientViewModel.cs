﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    public class ClientViewModel
    {
        [Required]
        [Range(0, int.MaxValue)]
        public int Id { get; set; }
        [Required]
        [Range(0, 1000)]
        public int USD { get; set; }
        [Required]
        [Range(0, 1000000)]
        public int LBP { get; set; }
    }
}
