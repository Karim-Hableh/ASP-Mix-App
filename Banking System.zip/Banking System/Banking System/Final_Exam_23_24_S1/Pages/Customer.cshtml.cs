using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class CustomerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
