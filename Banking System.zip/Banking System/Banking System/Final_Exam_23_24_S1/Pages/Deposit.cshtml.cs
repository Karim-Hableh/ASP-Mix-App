using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class DepositModel : PageModel
    {

		private readonly ClientService service;
		private readonly AppDbContext context;

		public DepositModel(ClientService service, AppDbContext context)
		{
			this.service = service;
			this.context = context;
		}
		[BindProperty]
		public ClientBindingModel ClientBindingModel { get; set; }
		public ClientViewModel ClientViewModel { get; set; }
		public void OnGet()
        {
        }

		public async Task<IActionResult> OnPostAsync()
		{
			if(!ModelState.IsValid)
			{
				return Page();
			}
			var customer1 = await context.ClientModel.FindAsync(ClientBindingModel.Id);
			if (customer1 == null)
			{
				ModelState.AddModelError("", "No customer with this id exists");
			}
			await service.WithdrawAsync(ClientBindingModel.Id, ClientBindingModel.USD, ClientBindingModel.LBP);
			return RedirectToPage("/Success", new { Id = ClientBindingModel.Id });

		}
    }
}
