using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class SuccessModel : PageModel
    {
        private readonly AppDbContext _context;

        public SuccessModel(AppDbContext context)
        {
            _context = context;
        }

        public ClientDataModel Customer { get; set; }
        public async Task<IActionResult> OnGet(int id)
        {
            Customer = await _context.ClientModel.FindAsync(id);
            if (Customer == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}
