using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class WithdrawModel : PageModel
    {

        private readonly ClientService service;
        private readonly AppDbContext context;

        public WithdrawModel(ClientService service ,AppDbContext context)
        {
            this.service = service;
            this.context = context;
        }
        [BindProperty]
        public ClientBindingModel ClientBindingModel { get; set; }
        public ClientViewModel ClientViewModel { get; set; }
        public void OnGet()
        {
        }

        public async Task <IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var customer = await context.ClientModel.FindAsync(ClientBindingModel.Id);
            if (customer == null)
            {
                ModelState.AddModelError("", "customer with this id doesnt exist");
                return Page();
            }

            if (customer.USD_Balance < ClientBindingModel.USD)
            {
				ModelState.AddModelError("", "Insufficient usd balance");
                return Page();
			}
            if(customer.LBP_Balance< ClientBindingModel.LBP)
            {
				ModelState.AddModelError("", "Insufficient lbp balance");
                return Page();
			}
            await service.WithdrawAsync(ClientBindingModel.Id,ClientBindingModel.USD,ClientBindingModel.LBP);

            return RedirectToPage("/Success", new { id = ClientBindingModel.Id });
		}
    }
}
