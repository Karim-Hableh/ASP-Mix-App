﻿using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;

namespace Final_Exam_23_24_S1.Services
{
    public class ClientService
    {
        private AppDbContext context;
        public ClientService(AppDbContext context)
        {
            this.context = context;
        }
        public async Task<IResult> AddCustomer(ClientRequest request)
        {
            var customer = new ClientDataModel
            {
                Name = request.Name,
                USD_Balance = request.USD_Balance,
                LBP_Balance = request.LBP_Balance,
            };
            context.Add(customer);
            await context.SaveChangesAsync();
            return Results.Ok(customer);
        }

        public async Task<IResult> CorrectBalance(int id, int USD, int LBP)
        {
            var newCustomer = context.ClientModel.FirstOrDefault(c=>c.Id == id);
            if (newCustomer == null)
            {
                return Results.NotFound("Customer with this id doesnt exist");
            }
            newCustomer.USD_Balance = USD;
            newCustomer.LBP_Balance = LBP;
            context.SaveChanges();
            return Results.Ok(newCustomer);
        }

        public IResult GetCustomerById(int id)
        {
            var customer= context.ClientModel.FirstOrDefault(c=> c.Id == id);
            if (customer == null)
            {
                return Results.NotFound("Customer with this id doesnt exist");
            }
            return Results.Ok(customer);
        }

        public async Task WithdrawAsync(int id, int usd,int lbp)
        {
            var customer = await context.ClientModel.FindAsync(id);
            customer.USD_Balance -= usd;
            customer.LBP_Balance -= lbp;
            await context.SaveChangesAsync();
        }
        public async Task DepositAsync(int id, int usd, int lbp)
        {
            var customer = await context.ClientModel.FindAsync(id);
            customer.USD_Balance += usd;
            customer.LBP_Balance += lbp;
            await context.SaveChangesAsync();
        }
    }
}
